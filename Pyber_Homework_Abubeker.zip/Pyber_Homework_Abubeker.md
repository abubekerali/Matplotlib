
#### Pyber Homework
Analysis
1. The total number of drivers is very high in Urban areas
2. The total number of drivers and total number of rides in rural area is very low
3. Drivers in suburban and rural areas earn high fares




```python
#Dependencies
import pandas as pd
import matplotlib.pyplot as plt
```


```python
#importing the files
city_df= pd.read_csv("D:\\Data_Science\\GW-DataAnalytics\\HomeWork\\matplotlib\\city_data.csv")
ride_df=pd.read_csv("D:\\Data_Science\\GW-DataAnalytics\\HomeWork\\matplotlib\\ride_data.csv")
```


```python
#checking the top five rows of ride data frame
ride_df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
#checking the top five rows of city data frame
city_df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Merging the city and ride data frames
city_ride=pd.merge(ride_df,city_df,how="left",on="city")
```


```python
#checking overall information of the city_ride data frame
city_ride.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 2407 entries, 0 to 2406
    Data columns (total 6 columns):
    city            2407 non-null object
    date            2407 non-null object
    fare            2407 non-null float64
    ride_id         2407 non-null int64
    driver_count    2407 non-null int64
    type            2407 non-null object
    dtypes: float64(1), int64(2), object(3)
    memory usage: 131.6+ KB
    


```python
#checking the head of city_ride_dataframe
city_ride.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
      <td>46</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
      <td>35</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
      <td>55</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
      <td>68</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>



### Bubble plot of ride sharing data


```python
#grouping the city_ride data frame by city & aggregate function is used
city_ride_group= city_ride.groupby("city",as_index=False).agg({"fare":"mean","ride_id":"count",
                                                               "driver_count":"first","type":"first"})
```


```python
city_ride_group.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>fare</th>
      <th>ride_id</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>23.928710</td>
      <td>31</td>
      <td>21</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>20.609615</td>
      <td>26</td>
      <td>67</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>37.315556</td>
      <td>9</td>
      <td>16</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>23.625000</td>
      <td>22</td>
      <td>21</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>21.981579</td>
      <td>19</td>
      <td>49</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Renaming columns of the grouped data frame city_ride_group
city_ride_renamed=city_ride_group.rename(columns={"city":"City","fare":"Average Fare","ride_id":"Ride_Count",
                                "driver_count":"Driver Count","type":"Type"})
```


```python
city_ride_renamed.columns
```




    Index(['City', 'Average Fare', 'Ride_Count', 'Driver Count', 'Type'], dtype='object')




```python
#creating a Color dictionary 
color_dict={"Urban":"lightcoral","Suburban":"lightskyblue","Rural":"gold"}
```


```python
#ploting the bubble plot using Ride Count as x_axis,Average Fare as Y_axis and Driver count as 
#size and is multiplied by 10 for best size proportion
plt.scatter(city_ride_renamed["Ride_Count"],city_ride_renamed["Average Fare"],
            s=city_ride_renamed["Driver Count"]*10,color=[color_dict.get(x) for x in city_ride_renamed["Type"]],alpha=0.5,edgecolors="black")
```




    <matplotlib.collections.PathCollection at 0x1e22bcbcd30>




```python
#Adding labels,title,x&y limit and grid to the bubble plot
plt.xlabel("Total Number of Rides(Per City)")
plt.ylabel("Average Fare($)")
plt.title("Pyber Ride Sharing Data(2016)")
plt.xlim(0,40)
plt.ylim(15,45)
plt.grid()
```


```python
#adding legend to the bubble plot
plt.legend(["Urban","Suburban","Rural"],loc="upper right")
```




    <matplotlib.legend.Legend at 0x1e22bc33518>




```python
#showing the final plot
plt.show()
```


![png](output_17_0.png)


### Total Fares by city type


```python
#grouping the city ride data frame with type 
city_ride_type=city_ride.groupby("type",
                                 as_index=False).agg({"fare":"sum",
                                "ride_id":"count","driver_count":"sum"})
```


```python
city_ride_type.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type</th>
      <th>fare</th>
      <th>ride_id</th>
      <th>driver_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>4255.09</td>
      <td>125</td>
      <td>727</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>20335.69</td>
      <td>657</td>
      <td>9730</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>40078.34</td>
      <td>1625</td>
      <td>64501</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Renaming columns of the grouped data frame city_ride_group
city_ride_type_re=city_ride_type.rename(columns={"type":"Type","fare":"Total Fare","ride_id":"Total Rides",
                                "driver_count":"Total Drivers"})
```


```python
city_ride_type_re.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>Total Fare</th>
      <th>Total Rides</th>
      <th>Total Drivers</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>4255.09</td>
      <td>125</td>
      <td>727</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>20335.69</td>
      <td>657</td>
      <td>9730</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>40078.34</td>
      <td>1625</td>
      <td>64501</td>
    </tr>
  </tbody>
</table>
</div>




```python
#assigning color and explode for the pie chart
color=("gold","lightskyblue","lightcoral")
explode=(0.1,0.1,0)
```


```python
# Tell matplotlib to create a pie chart based upon the above data
plt.pie(city_ride_type_re["Total Fare"], labels=city_ride_type_re["Type"], explode=explode,colors=color,
        autopct="%1.1f%%", shadow=True, startangle=140)
```




    ([<matplotlib.patches.Wedge at 0x1e22b8a4278>,
      <matplotlib.patches.Wedge at 0x1e22b904f60>,
      <matplotlib.patches.Wedge at 0x1e22b911780>],
     [<matplotlib.text.Text at 0x1e22b904518>,
      <matplotlib.text.Text at 0x1e22b90ad68>,
      <matplotlib.text.Text at 0x1e22b919588>],
     [<matplotlib.text.Text at 0x1e22b904a20>,
      <matplotlib.text.Text at 0x1e22b911320>,
      <matplotlib.text.Text at 0x1e22b919b00>])




```python
plt.title("%of Total Fares by City Type")
```




    <matplotlib.text.Text at 0x1e22b8bec18>




```python
plt.show()
```


![png](output_26_0.png)


### Total Rides by City Type


```python
# create a pie chart based upon the city_ride_type_re data frame 
plt.pie(city_ride_type_re["Total Rides"], labels=city_ride_type_re["Type"], explode=explode,colors=color, 
        autopct="%1.1f%%", shadow=True, startangle=140)
```




    ([<matplotlib.patches.Wedge at 0x1e22b9ad8d0>,
      <matplotlib.patches.Wedge at 0x1e22b9bc0f0>,
      <matplotlib.patches.Wedge at 0x1e22b9c57f0>],
     [<matplotlib.text.Text at 0x1e22b9b3630>,
      <matplotlib.text.Text at 0x1e22b9bcd68>,
      <matplotlib.text.Text at 0x1e22b9cb5f8>],
     [<matplotlib.text.Text at 0x1e22b9b3ba8>,
      <matplotlib.text.Text at 0x1e22b9c52b0>,
      <matplotlib.text.Text at 0x1e22b9cbb70>])




```python
#Setting up title for the pie chart
plt.title("%of Total Rides by City Type")
```




    <matplotlib.text.Text at 0x1e22b95b7b8>




```python
#showing the total rides by city type pie chart
plt.show()
```


![png](output_30_0.png)


### Total Drivers by City Type


```python
# creating  a pie chart based upon the percentage of the total drivers in a city
plt.pie(city_ride_type_re["Total Drivers"], labels=city_ride_type_re["Type"], explode=explode,colors=color, 
        autopct="%1.1f%%", shadow=True, startangle=140)
```




    ([<matplotlib.patches.Wedge at 0x1e22ba3f240>,
      <matplotlib.patches.Wedge at 0x1e22ba48ac8>,
      <matplotlib.patches.Wedge at 0x1e22ba583c8>],
     [<matplotlib.text.Text at 0x1e22ba3ffd0>,
      <matplotlib.text.Text at 0x1e22ba508d0>,
      <matplotlib.text.Text at 0x1e22ba611d0>],
     [<matplotlib.text.Text at 0x1e22ba48588>,
      <matplotlib.text.Text at 0x1e22ba50e48>,
      <matplotlib.text.Text at 0x1e22ba61748>])




```python
#assigning title for the pie chart
plt.title("%Total drivers by City Type")
```




    <matplotlib.text.Text at 0x1e22ba0fe80>




```python
#Displaying the percentage of totaldrivers by city type pie chart
plt.show()
```


![png](output_34_0.png)

